# -*- coding: utf-8 -*-
import pandas as pd
import csv
import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CoronaVisualizerStack-StateTable9728C7E5-15MMR3XLKXUN')
def handler(event, context):
    data = pd.read_csv('https://github.com/nytimes/covid-19-data/raw/master/us-states.csv')

    print("here")
    statename_to_abbr = {
        # Other
        'District of Columbia': 'DC',
        'Guam': 'GU',
        'Virgin Islands': 'VI',
        'Puerto Rico': 'PR',
        'Northern Mariana Islands' : 'MP',


        # States
        'Alabama': 'AL',
        'Montana': 'MT',
        'Alaska': 'AK',
        'Nebraska': 'NE',
        'Arizona': 'AZ',
        'Nevada': 'NV',
        'Arkansas': 'AR',
        'New Hampshire': 'NH',
        'California': 'CA',
        'New Jersey': 'NJ',
        'Colorado': 'CO',
        'New Mexico': 'NM',
        'Connecticut': 'CT',
        'New York': 'NY',
        'Delaware': 'DE',
        'North Carolina': 'NC',
        'Florida': 'FL',
        'North Dakota': 'ND',
        'Georgia': 'GA',
        'Ohio': 'OH',
        'Hawaii': 'HI',
        'Oklahoma': 'OK',
        'Idaho': 'ID',
        'Oregon': 'OR',
        'Illinois': 'IL',
        'Pennsylvania': 'PA',
        'Indiana': 'IN',
        'Rhode Island': 'RI',
        'Iowa': 'IA',
        'South Carolina': 'SC',
        'Kansas': 'KS',
        'South Dakota': 'SD',
        'Kentucky': 'KY',
        'Tennessee': 'TN',
        'Louisiana': 'LA',
        'Texas': 'TX',
        'Maine': 'ME',
        'Utah': 'UT',
        'Maryland': 'MD',
        'Vermont': 'VT',
        'Massachusetts': 'MA',
        'Virginia': 'VA',
        'Michigan': 'MI',
        'Washington': 'WA',
        'Minnesota': 'MN',
        'West Virginia': 'WV',
        'Mississippi': 'MS',
        'Wisconsin': 'WI',
        'Missouri': 'MO',
        'Wyoming': 'WY',
    }

    abbState = []
    for row in data['state']:
      abbState.append(statename_to_abbr.get(row))

    data["abbState"] = abbState

    data = data.sort_values(by=['state', 'date'])

    stateArray = statename_to_abbr.keys()
    #print(data[data['abbState']=='Wyoming'])
    with table.batch_writer() as batch:
        for state in stateArray:
            stateData = data[data['state']==state]
            finalState = {
                "id": statename_to_abbr[state],
                "name": state,
                "days": []
            }
            for index, row in stateData.iterrows():
                finalState["days"].append({
                    "date": row['date'],
                    "cases": row['cases'],
                    "deaths": row['deaths']
                })
            print(finalState)
            batch.put_item(finalState)
